﻿using System.ComponentModel.DataAnnotations;

namespace WildlifeRefuge.Models
{
    public class Animal
    {
        //TODO: Implement me
    }
}

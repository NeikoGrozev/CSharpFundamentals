﻿using Microsoft.AspNetCore.Mvc;
using WildlifeRefuge.Models;
using System.Linq;

namespace WildlifeRefuge.Controllers
{
    public class AnimalController : Controller
    {
        private readonly WildlifeRefugeDbContext context;

        public AnimalController(WildlifeRefugeDbContext context)
        {
            this.context = context;
        }

        public IActionResult Index()
        {
            //TODO: Implement me
            return null;
        }

        [HttpGet]
        public IActionResult Create()
        {
            //TODO: Implement me
            return null;
        }

        [HttpPost]
        public IActionResult Create(Animal animal)
        {
            //TODO: Implement me
            return null;
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            //TODO: Implement me
            return null;
        }

        [HttpPost]
        public IActionResult Edit(Animal animal)
        {
            //TODO: Implement me
            return null;
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            //TODO: Implement me
            return null;
        }

        [HttpPost]
        public IActionResult Delete(Animal animal)
        {
            //TODO: Implement me
            return null;
        }
    }
}